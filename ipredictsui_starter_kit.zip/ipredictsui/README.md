
# IPredictSui — Polymarket-style prediction markets on Sui

**Tagline:** Infinite — Forecast — Network → *IPredictSui*

This is a monorepo with:
- `contracts/` — Sui Move package (`suix_markets`) with creator fee (0.01% = 1 bps) and protocol fee (0.05% = 5 bps) parameters.
- `web/` — Next.js 14 + TypeScript app (wallet connect, basic pages).
- `indexer/` — Node + Prisma skeleton for indexing on-chain events (optional for v1).

## Quickstart (no local setup, easiest)
1) Fork this repo to your GitHub.
2) Open **GitHub Codespaces** on the repo (one-click cloud dev environment).
3) In Codespaces terminal, run:
```bash
# 1) Install Sui CLI
bash <(curl -s https://install.sui.io)   && sui --version

# 2) Install deps
cd web && corepack enable && pnpm i && cd ..
cd indexer && pnpm i && cd ..

# 3) Create env files (edit values as needed)
cp web/.env.example web/.env
cp indexer/.env.example indexer/.env
```

4) Get a Sui **testnet** wallet (Sui Wallet extension) and faucet some SUI (in Wallet → Switch to testnet → Faucet).  
5) Deploy contracts to testnet:
```bash
cd contracts
sui client switch --env testnet
sui client publish --gas-budget 200000000
# Copy the published package ID printed in the output and paste it into web/.env (NEXT_PUBLIC_SUI_PACKAGE_ID)
```

6) Run the Next.js app locally (in Codespaces):
```bash
cd web
pnpm dev
# Preview the web app in the Codespaces preview port
```

## Deploy to production
- **Frontend:** Vercel (import your repo, set env vars from `web/.env.example`, choose app dir `web/`).
- **Indexer:** Railway, Render, or Fly.io (set env vars from `indexer/.env.example`, provision a free Postgres from **Neon**).
- **Contracts:** Already on Sui testnet; move to mainnet when ready (same publish command with `--env mainnet`).

---

### Key params (can be changed in env or contract constants)
- Creator fee: **1 bps = 0.01%**
- Protocol fee: **5 bps = 0.05%**
- LP fee (in CPMM math/quotes): **30 bps = 0.30%** (used in UI, actual AMM fee is part of pricing)

---

### NOTE
This is a scaffold with safe defaults and placeholders. You (or a dev) will extend:
- Market resolution/oracles
- Disputes
- Full CPMM math and event indexing

The web app connects to Sui Wallet and shows a basic flow to create a market object (placeholder) and read states.
