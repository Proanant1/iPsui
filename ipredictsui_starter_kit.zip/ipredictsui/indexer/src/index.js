
import { SuiClient } from '@mysten/sui.js';
const rpcUrl = process.env.SUI_RPC || 'https://fullnode.testnet.sui.io:443';
const PACKAGE_ID = process.env.SUI_PACKAGE_ID || '0xPACKAGE_ID_HERE';

const client = new SuiClient({ url: rpcUrl });

async function main() {
  console.log('Indexer skeleton. TODO: Subscribe to suix_markets events from', PACKAGE_ID);
  // Example: client.subscribeEvent({ filter: { Package: PACKAGE_ID }}, evt => console.log(evt));
}
main().catch(console.error);
