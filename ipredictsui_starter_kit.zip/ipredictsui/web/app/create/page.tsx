
'use client';

import { useState } from 'react';
import { ConnectButton, WalletProvider } from '@mysten/wallet-kit';
import { TransactionBlock, SuiClient } from '@mysten/sui.js';

const rpcUrl = process.env.NEXT_PUBLIC_SUI_RPC || 'https://fullnode.testnet.sui.io:443';
const PACKAGE_ID = process.env.NEXT_PUBLIC_SUI_PACKAGE_ID || '0xPACKAGE_ID_HERE';

export default function CreateMarket() {
  const [name, setName] = useState('Sample Market');
  const [desc, setDesc] = useState('Describe the prediction...');
  const [treasury, setTreasury] = useState('0xYOUR_TREASURY_ADDRESS');

  const create = async () => {
    // In a real app, use wallet signer. Here we just show the tx structure.
    const tx = new TransactionBlock();
    // suix_markets::market::create_market(name, description, protocol_treasury, ctx)
    tx.moveCall({
      target: `${PACKAGE_ID}::market::create_market`,
      arguments: [
        tx.pure.string(name),
        tx.pure.string(desc),
        tx.pure.address(treasury),
      ],
    });
    alert('Constructed create_market transaction. Connect your wallet in a real signer flow.');
  };

  return (
    <WalletProvider>
      <main style={{ padding: 24, maxWidth: 720, margin: '0 auto' }}>
        <header style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <h2>Create Market</h2>
          <ConnectButton />
        </header>
        <div style={{ display: 'grid', gap: 12, marginTop: 24 }}>
          <input value={name} onChange={e=>setName(e.target.value)} placeholder="Market name" />
          <textarea value={desc} onChange={e=>setDesc(e.target.value)} placeholder="Description" rows={4} />
          <input value={treasury} onChange={e=>setTreasury(e.target.value)} placeholder="Protocol Treasury Address" />
          <button onClick={create}>Create (build tx)</button>
          <p style={{ color: '#666' }}>Note: This scaffold builds the transaction; integrate with wallet signer to submit.</p>
        </div>
      </main>
    </WalletProvider>
  );
}
