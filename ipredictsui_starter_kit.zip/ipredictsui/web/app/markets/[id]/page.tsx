
'use client';

import { useState } from 'react';
import { ConnectButton, WalletProvider } from '@mysten/wallet-kit';

export default function MarketDetail({ params }: { params: { id: string } }) {
  const { id } = params;
  const [tradeValue, setTradeValue] = useState(1000);

  const previewFees = () => {
    const v = Number(tradeValue);
    const creator = v * 1 / 10000;  // 1 bps
    const protocol = v * 5 / 10000; // 5 bps
    const lp = v * 30 / 10000;      // 30 bps (illustrative)
    alert(`Trade ${v}:
- LP fee ~ ${lp}
- Creator fee ${creator}
- Protocol fee ${protocol}`);
  };

  return (
    <WalletProvider>
      <main style={{ padding: 24, maxWidth: 720, margin: '0 auto' }}>
        <header style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <h2>Market #{id}</h2>
          <ConnectButton />
        </header>
        <div style={{ marginTop: 24 }}>
          <p>Demo market page. CPMM, outcomes, and trades will be wired here.</p>
          <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginTop: 12 }}>
            <input type="number" value={tradeValue} onChange={e => setTradeValue(Number(e.target.value))} />
            <button onClick={previewFees}>Preview Fees</button>
          </div>
        </div>
      </main>
    </WalletProvider>
  );
}
