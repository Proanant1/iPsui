
'use client';

import { ConnectButton, WalletProvider } from '@mysten/wallet-kit';
import Link from 'next/link';

export default function Page() {
  return (
    <WalletProvider>
      <main style={{ padding: 24, maxWidth: 960, margin: '0 auto' }}>
        <header style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <h1>IPredictSui</h1>
          <ConnectButton />
        </header>

        <section style={{ marginTop: 24 }}>
          <p>Infinite — Forecast — Network on Sui. Create markets, trade, and earn creator fees.</p>
          <div style={{ display: 'flex', gap: 12, marginTop: 12 }}>
            <Link href="/create">Create Market</Link>
            <Link href="/markets/demo">View Demo Market</Link>
          </div>
        </section>
      </main>
    </WalletProvider>
  );
}
